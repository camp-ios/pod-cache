//
//  libidn.h
//  libidn
//
//  Created by Alexander Dodatko on 2/16/17.
//  Copyright © 2017 chrisballinger. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for libidn.
FOUNDATION_EXPORT double libidnVersionNumber;

//! Project version string for libidn.
FOUNDATION_EXPORT const unsigned char libidnVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <libidn/PublicHeader.h>

#import "NSString+IDN.h"
