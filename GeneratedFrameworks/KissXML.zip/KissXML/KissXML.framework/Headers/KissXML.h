#import <Foundation/Foundation.h>

#if __has_include("DDXMLElementAdditions.h")
    #import "DDXMLElementAdditions.h"
#endif
#import "NSString+DDXML.h"
#import "DDXML.h"
#import "DDXMLDocument.h"
#import "DDXMLElement.h"
#import "DDXMLNode.h"

FOUNDATION_EXPORT double KissXMLVersionNumber;
FOUNDATION_EXPORT const unsigned char KissXMLVersionString[];

